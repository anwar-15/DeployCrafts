from django.db.models.signals import  Signal
from django.dispatch import receiver
user_created_signal = Signal()

